package com.example.testfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
