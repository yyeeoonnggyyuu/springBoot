package com.example.testfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestfileApplication.class, args);
	}

}
